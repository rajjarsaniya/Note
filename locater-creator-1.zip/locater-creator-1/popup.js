document.getElementById("start").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: startLocatorMode
  });
});

function startLocatorMode() {
  if (window.__locatorModeActive) return;
  window.__locatorModeActive = true;

  alert("Locator mode ON\nHover and click an element");

  // 🔹 Highlight box
  const highlight = document.createElement("div");
  Object.assign(highlight.style, {
    position: "absolute",
    background: "rgba(0,123,255,0.3)",
    pointerEvents: "none",
    zIndex: "999999"
  });
  document.body.appendChild(highlight);

  function move(e) {
    const r = e.target.getBoundingClientRect();
    highlight.style.top = r.top + scrollY + "px";
    highlight.style.left = r.left + scrollX + "px";
    highlight.style.width = r.width + "px";
    highlight.style.height = r.height + "px";
  }

  function click(e) {
    e.preventDefault();
    e.stopPropagation();

    // 🔥 STOP PAGE LISTENERS BEFORE SHOWING MODAL
    document.removeEventListener("mousemove", move);
    document.removeEventListener("click", click, true);

    const el = e.target;
    const result = getValidatedLocator(el);

    let playwrightCode = "";
    let seleniumCode = "";

    if (result.type === "unique") {
      playwrightCode = `page.locator("${result.locator}")`;
      seleniumCode = `driver.findElement(By.cssSelector("${result.locator}"));`;
    } else {
      playwrightCode = `page.locator("${result.locator}").nth(${result.index})`;
      seleniumCode = `driver.findElement(By.xpath("${result.xpathIndexed}"));`;
    }

    showCopyModal({ playwrightCode, seleniumCode, result });
  }

  document.addEventListener("mousemove", move);
  document.addEventListener("click", click, true);

  // 🔹 MODAL UI
  function showCopyModal({ playwrightCode, seleniumCode, result }) {
    const modal = document.createElement("div");
    modal.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: #fff;
      border-radius: 6px;
      padding: 16px;
      z-index: 1000000;
      font-family: Arial;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
      min-width: 280px;
    `;

    modal.innerHTML = `
      <h3 style="margin-top:0">Copy Locator</h3>

      <label style="display:block;margin-bottom:6px">
        <input type="checkbox" id="pwCheck" checked />
        Playwright
      </label>

      <label style="display:block;margin-bottom:12px">
        <input type="checkbox" id="selCheck" />
        Selenium
      </label>

      <button id="copyBtn" style="
        width:100%;
        padding:8px;
        cursor:pointer;
        background:#0d6efd;
        color:#fff;
        border:none;
        border-radius:4px;
      ">
        Copy
      </button>
    `;

    // 🔒 Prevent modal clicks from affecting page
    modal.addEventListener("click", e => e.stopPropagation());

    document.body.appendChild(modal);

    modal.querySelector("#copyBtn").addEventListener("click", () => {
      const copyPlaywright = modal.querySelector("#pwCheck").checked;
      const copySelenium = modal.querySelector("#selCheck").checked;

      if (!copyPlaywright && !copySelenium) {
        alert("Please select at least one option.");
        return;
      }

      let clipboardText = "";

      if (copyPlaywright) {
        clipboardText += `Playwright:\n${playwrightCode}\n\n`;
      }

      if (copySelenium) {
        clipboardText += `Selenium:\n${seleniumCode}`;
      }

      navigator.clipboard.writeText(clipboardText.trim());

      alert(
        `LOCATOR GENERATED ✅\n\n` +
        `Base Locator:\n${result.locator}\n\n` +
        `Matches Found: ${result.count}\n` +
        (result.type === "indexed"
          ? `Selected Index: ${result.index + 1}\n\n`
          : "\n") +
        `Copied:\n\n${clipboardText}`
      );

      modal.remove();
      cleanup();
    });
  }

  function cleanup() {
    highlight.remove();
    window.__locatorModeActive = false;
  }

  // ---------------- CORE FUNCTIONS ----------------

  function getValidatedLocator(el) {
    const baseLocator = getBaseLocator(el);

    let elements;
    try {
      elements = Array.from(document.querySelectorAll(baseLocator));
    } catch {
      elements = [];
    }

    const count = elements.length;

    if (count === 1) {
      return { type: "unique", locator: baseLocator, count };
    }

    return {
      type: "indexed",
      locator: baseLocator,
      count,
      index: elements.indexOf(el),
      xpathIndexed: buildIndexedXPath(el)
    };
  }

  function getBaseLocator(el) {
    if (el.id) return `#${el.id}`;

    const testId = el.getAttribute("data-testid");
    if (testId) return `[data-testid="${testId}"]`;

    if (el.className) {
      const cls = el.className.trim().split(/\s+/).join(".");
      return `${el.tagName.toLowerCase()}.${cls}`;
    }

    return buildIndexedXPath(el);
  }

  function buildIndexedXPath(el) {
    let path = "";
    while (el && el.nodeType === 1) {
      let index = 1;
      let sibling = el.previousSibling;

      while (sibling) {
        if (sibling.nodeType === 1 && sibling.tagName === el.tagName) index++;
        sibling = sibling.previousSibling;
      }

      path = `/${el.tagName.toLowerCase()}[${index}]` + path;
      el = el.parentNode;
    }
    return path;
  }
}
