// document.getElementById("start").addEventListener("click", async () => {
//   const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

//   chrome.scripting.executeScript({
//     target: { tabId: tab.id },
//     func: startLocatorMode
//   });
// });

// function startLocatorMode() {
//   if (window.__locatorModeActive) return;
//   window.__locatorModeActive = true;

//   alert("Locator mode ON\nHover and click an element");

//   const highlight = document.createElement("div");
//   Object.assign(highlight.style, {
//     position: "absolute",
//     background: "rgba(0,123,255,0.3)",
//     pointerEvents: "none",
//     zIndex: "999999"
//   });
//   document.body.appendChild(highlight);

//   function move(e) {
//     const r = e.target.getBoundingClientRect();
//     highlight.style.top = r.top + scrollY + "px";
//     highlight.style.left = r.left + scrollX + "px";
//     highlight.style.width = r.width + "px";
//     highlight.style.height = r.height + "px";
//   }

//   function click(e) {
//     e.preventDefault();
//     e.stopPropagation();

//     document.removeEventListener("mousemove", move);
//     document.removeEventListener("click", click, true);

//     const el = e.target;
//     const best = getBestUniqueLocator(el);

//     const playwrightCode = `page.locator("${best.value}")`;
//     const seleniumCode =
//       best.type === "css"
//         ? `driver.findElement(By.cssSelector("${best.value}"));`
//         : `driver.findElement(By.xpath("${best.value}"));`;

//     showCopyModal({ playwrightCode, seleniumCode, best });
//   }

//   document.addEventListener("mousemove", move);
//   document.addEventListener("click", click, true);

//   // ================= MODAL =================
//   function showCopyModal({ playwrightCode, seleniumCode, best }) {
//     const modal = document.createElement("div");
//     modal.style.cssText = `
//       position: fixed;
//       top: 50%;
//       left: 50%;
//       transform: translate(-50%, -50%);
//       background: #fff;
//       padding: 16px;
//       border-radius: 6px;
//       z-index: 1000000;
//       min-width: 280px;
//       font-family: Arial;
//       box-shadow: 0 6px 20px rgba(0,0,0,.3);
//     `;

//     modal.innerHTML = `
//       <h3 style="margin-top:0">Copy Locator</h3>

//       <label><input type="checkbox" id="pw" checked /> Playwright</label><br>
//       <label><input type="checkbox" id="sel" /> Selenium</label><br><br>

//       <button id="copy" style="
//         width:100%;
//         padding:8px;
//         background:#0d6efd;
//         color:#fff;
//         border:none;
//         border-radius:4px;
//         cursor:pointer;
//       ">Copy</button>
//     `;

//     modal.addEventListener("click", e => e.stopPropagation());
//     document.body.appendChild(modal);

//     modal.querySelector("#copy").onclick = () => {
//       const pw = modal.querySelector("#pw").checked;
//       const sel = modal.querySelector("#sel").checked;

//       if (!pw && !sel) {
//         alert("Select at least one option");
//         return;
//       }

//       let text = "";
//       if (pw) text += `Playwright:\n${playwrightCode}\n\n`;
//       if (sel) text += `Selenium:\n${seleniumCode}`;

//       navigator.clipboard.writeText(text.trim());

//       alert(
//         `LOCATOR GENERATED ✅\n\n` +
//         `Locator:\n${best.value}\n\n` +
//         `Type: ${best.type.toUpperCase()}\n` +
//         `Stability Score: ${best.score}`
//       );

//       modal.remove();
//       cleanup();
//     };
//   }

//   function cleanup() {
//     highlight.remove();
//     window.__locatorModeActive = false;
//   }

//   // ================= LOCATOR ENGINE =================

//   function getBestUniqueLocator(el) {
//     const candidates = [];

//     function add(type, value, score) {
//       if (isUnique(type, value, el)) {
//         candidates.push({ type, value, score });
//       }
//     }

//     // ---------- CSS ----------
//     if (el.id) add("css", `#${el.id}`, 100);

//     const testId = el.getAttribute("data-testid");
//     if (testId) add("css", `[data-testid="${testId}"]`, 95);

//     const name = el.getAttribute("name");
//     if (name) add("css", `[name="${name}"]`, 90);

//     // ---------- XPATH ----------
//     if (el.id) add("xpath", `//*[@id="${el.id}"]`, 100);
//     if (testId) add("xpath", `//*[@data-testid="${testId}"]`, 95);

//     const aria = el.getAttribute("aria-label");
//     if (aria) add("xpath", `//*[@aria-label="${aria}"]`, 85);

//     const text = el.innerText?.trim();
//     if (text && text.length < 40) {
//       add(
//         "xpath",
//         `//${el.tagName.toLowerCase()}[normalize-space()="${text}"]`,
//         80
//       );
//     }

//     // ---------- CLASS ----------
//     if (el.className) {
//       const cls = el.className.trim().split(/\s+/).join(".");
//       add("css", `${el.tagName.toLowerCase()}.${cls}`, 60);
//     }

//     // ---------- FALLBACK (INDEXED RELATIVE XPATH) ----------
//     add("xpath", buildIndexedRelativeXPath(el), 40);

//     return candidates.sort((a, b) => b.score - a.score)[0];
//   }

//   function isUnique(type, locator, el) {
//     try {
//       let matches = [];

//       if (type === "css") {
//         matches = Array.from(document.querySelectorAll(locator));
//       } else {
//         const result = document.evaluate(
//           locator,
//           document,
//           null,
//           XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
//           null
//         );
//         for (let i = 0; i < result.snapshotLength; i++) {
//           matches.push(result.snapshotItem(i));
//         }
//       }

//       return matches.length === 1 && matches[0] === el;
//     } catch {
//       return false;
//     }
//   }

//   function buildIndexedRelativeXPath(el) {
//     let path = "";
//     while (el && el.nodeType === 1) {
//       let index = 1;
//       let sib = el.previousSibling;
//       while (sib) {
//         if (sib.nodeType === 1 && sib.tagName === el.tagName) index++;
//         sib = sib.previousSibling;
//       }
//       path = `/${el.tagName.toLowerCase()}[${index}]` + path;
//       el = el.parentNode;
//     }
//     return `//${path.replace(/^\/+/, "")}`;
//   }
// }

document.getElementById("start").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: startLocatorMode
  });
});

function startLocatorMode() {
  if (window.__locatorModeActive) return;
  window.__locatorModeActive = true;

  alert("Locator mode ON\nHover and click an element");

  const highlight = document.createElement("div");
  Object.assign(highlight.style, {
    position: "absolute",
    background: "rgba(0,123,255,0.3)",
    pointerEvents: "none",
    zIndex: "999999"
  });
  document.body.appendChild(highlight);

  function move(e) {
    const r = e.target.getBoundingClientRect();
    highlight.style.top = r.top + scrollY + "px";
    highlight.style.left = r.left + scrollX + "px";
    highlight.style.width = r.width + "px";
    highlight.style.height = r.height + "px";
  }

  function click(e) {
    e.preventDefault();
    e.stopPropagation();

    document.removeEventListener("mousemove", move);
    document.removeEventListener("click", click, true);

    const el = e.target;

    const playwright = selectBestPlaywrightLocator(el);
    const selenium = selectBestSeleniumLocator(el);

    showCopyModal(playwright, selenium);
  }

  document.addEventListener("mousemove", move);
  document.addEventListener("click", click, true);

  function cleanup() {
    highlight.remove();
    window.__locatorModeActive = false;
  }

  // ================= PLAYWRIGHT =================

  function selectBestPlaywrightLocator(el) {
    const candidates = [];

    const testId = el.getAttribute("data-testid");
    if (testId) {
      candidates.push({
        code: `page.getByTestId("${testId}")`,
        matches: 1,
        score: 100
      });
    }

    const role = el.getAttribute("role");
    const text = el.innerText?.trim();
    if (role && text) {
      const count = countByXPath(`//*[@role="${role}" and normalize-space()="${text}"]`);
      candidates.push({
        code: `page.getByRole("${role}", { name: "${text}" })`,
        matches: count,
        score: 95
      });
    }

    if (text) {
      const count = countByXPath(`//*[normalize-space()="${text}"]`);
      candidates.push({
        code: `page.getByText("${text}", { exact: true })`,
        matches: count,
        score: 85
      });
    }

    const css = getCssSelector(el);
    if (css) {
      const count = document.querySelectorAll(css).length;
      if (count === 1) {
        candidates.push({
          code: `page.locator("${css}")`,
          matches: 1,
          score: 70
        });
      } else if (count > 1) {
        const index = [...document.querySelectorAll(css)].indexOf(el);
        candidates.push({
          code: `page.locator("${css}").nth(${index})`,
          matches: 1,
          score: 60
        });
      }
    }

    return pickBest(candidates);
  }

  // ================= SELENIUM =================

  function selectBestSeleniumLocator(el) {
    const candidates = [];

    if (el.id) {
      candidates.push({
        code: `driver.findElement(By.id("${el.id}"));`,
        matches: 1,
        score: 85
      });
    }

    if (el.name) {
      const count = document.getElementsByName(el.name).length;
      candidates.push({
        code: `driver.findElement(By.name("${el.name}"));`,
        matches: count,
        score: 80
      });
    }

    if (el.tagName === "A" && el.innerText?.trim()) {
      const text = el.innerText.trim();
      const count = countByXPath(`//a[normalize-space()="${text}"]`);
      candidates.push({
        code: `driver.findElement(By.linkText("${text}"));`,
        matches: count,
        score: 75
      });
    }

    const css = getCssSelector(el);
    if (css) {
      const count = document.querySelectorAll(css).length;
      if (count === 1) {
        candidates.push({
          code: `driver.findElement(By.cssSelector("${css}"));`,
          matches: 1,
          score: 70
        });
      }
    }

    const xpath = buildIndexedXPath(el);
    candidates.push({
      code: `driver.findElement(By.xpath("${xpath}"));`,
      matches: 1,
      score: 50
    });

    return pickBest(candidates);
  }

  // ================= CORE =================

  function pickBest(candidates) {
    return candidates
      .filter(c => c.matches === 1)
      .sort((a, b) => b.score - a.score)[0];
  }

  function countByXPath(xpath) {
    const result = document.evaluate(
      xpath,
      document,
      null,
      XPathResult.ORDERED_NODE_SNAPSHOT_TYPE,
      null
    );
    return result.snapshotLength;
  }

  function getCssSelector(el) {
    if (el.id) return `#${el.id}`;

    if (el.className) {
      const cls = el.className.trim().split(/\s+/).join(".");
      return `${el.tagName.toLowerCase()}.${cls}`;
    }

    return null;
  }

  function buildIndexedXPath(el) {
    let path = "";
    while (el && el.nodeType === 1) {
      let index = 1;
      let sibling = el.previousSibling;
      while (sibling) {
        if (sibling.nodeType === 1 && sibling.tagName === el.tagName) index++;
        sibling = sibling.previousSibling;
      }
      path = `/${el.tagName.toLowerCase()}[${index}]` + path;
      el = el.parentNode;
    }
    return path;
  }

  // ================= MODAL =================

  function showCopyModal(playwright, selenium) {
    const modal = document.createElement("div");
    modal.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: #fff;
      padding: 16px;
      z-index: 1000000;
      border-radius: 6px;
      font-family: Arial;
      box-shadow: 0 6px 20px rgba(0,0,0,0.3);
      min-width: 300px;
    `;

    modal.innerHTML = `
      <h3>Copy Locator</h3>
      <label><input type="checkbox" id="pw" checked /> Playwright</label><br>
      <label><input type="checkbox" id="sel" checked /> Selenium</label><br><br>
      <button id="copy">Copy</button>
    `;

    modal.querySelector("#copy").onclick = () => {
      let text = "";
      if (modal.querySelector("#pw").checked)
        text += `Playwright:\n${playwright.code}\n\n`;
      if (modal.querySelector("#sel").checked)
        text += `Selenium:\n${selenium.code}`;

      navigator.clipboard.writeText(text.trim());
      modal.remove();
      cleanup();
    };

    document.body.appendChild(modal);
  }
}
